from tkinter import *
import keyboard

x1 = 200
x2 = 300
y1 = 200
y2 = 300

def rght(event):
    c.delete(ALL)
    global x1, x2
    x1+=10
    x2+=10
    c.create_rectangle(x1, y1, x2, y2)

def lft(evnet):
    c.delete(ALL)
    global x1, x2
    x1-=10
    x2-=10
    c.create_rectangle(x1, y1, x2, y2)

def pp(event):
    c.delete(ALL)
    global y1, y2
    y1-=10
    y2-=10
    c.create_rectangle(x1, y1, x2, y2)

def dwn(event):
    c.delete(ALL)
    global y1, y2
    y1+=10
    y2+=10
    c.create_rectangle(x1, y1, x2, y2)

window = Tk()
c = Canvas(window, width = 500, height = 500)
c.pack()
c.create_rectangle(x1, y1, x2, y2)
window.bind('<Left>', lft)
window.bind('<Right>', rght)
window.bind('<Up>', pp)
window.bind('<Down>', dwn)
window.mainloop()