from tkinter import *

x1=100
y1=100
x2=200
y2=200

window= Tk()

w = Canvas(window, width = 300, height = 300)
w.pack()

w.create_rectangle(x1, y1, x2, y2)

def c1(event):
    w.delete(ALL)
    global x1, x2, y1, y2
    x1 -= 10
    y1-=10
    x2+=10
    y2+=10
    w.create_rectangle(x1, y1, x2, y2)
    
def c2(event):
    w.delete(ALL)
    global x1, x2, y1, y2
    x1+=10
    y1+=10
    x2-=10
    y2-=10
    w.create_rectangle(x1, y1, x2, y2)
    
window.bind("<Button-1>", c1)
window.bind("<Button-2>", c2)
window.mainloop()