from tkinter import *
import random

window = Tk()
c = Canvas(window, width = 500, height = 500)
c.pack()
clr = ["lightgreen", "skyblue", "yellow", "pink", "gray", "white", "black"]

for i in range(5):
    x1 = random.randint(1, 400)
    x2 = random.randint(1, 400)
    y1 = random.randint(1, 400)
    y2 = random.randint(1, 400)
    flclr = random.choice(clr)
    c.create_rectangle(x1, y1, x2, y2, fill = flclr)

window.mainloop()