from tkinter import *

window = Tk()

x1 = Label(window, text = "아이디")
x1.grid(row = 0, column = 0)
x2 = Label(window, text = "패스워드")
x2.grid(row = 1, column = 0)

y1 = Entry(window).grid(row = 0, column = 1)
y2 = Entry(window).grid(row = 1, column = 1)

f = Frame(window)
z1 = Button(f, text = "로그인").pack(side=LEFT)
z2 = Button(f, text = "취소").pack(side=LEFT)
f.grid(row = 2, column = 0, columnspan = 1)
window.mainloop()