from tkinter import *

x1 = 200
x2 = 300
y1 = 200
y2 = 300

def rght():
    c.delete(ALL)
    global x1, x2
    x1+=10
    x2+=10
    c.create_rectangle(x1, y1, x2, y2)

def lft():
    c.delete(ALL)
    global x1, x2
    x1-=10
    x2-=10
    c.create_rectangle(x1, y1, x2, y2)

def pp():
    c.delete(ALL)
    global y1, y2
    y1-=10
    y2-=10
    c.create_rectangle(x1, y1, x2, y2)

def dwn():
    c.delete(ALL)
    global y1, y2
    y1+=10
    y2+=10
    c.create_rectangle(x1, y1, x2, y2)

window = Tk()
c = Canvas(window, width = 500, height = 500)
c.pack()
c.create_rectangle(x1, y1, x2, y2)

f = Frame(window)
f.pack()

b1 = Button(f, text = "LEFT", command = lft)
b1.grid(row = 0, column = 0)
b2 = Button(f, text = "RIGHT", command = rght)
b2.grid(row = 0, column = 1)
b3 = Button(f, text = "UP", command = pp)
b3.grid(row = 0, column = 2)
b4 = Button(f, text = "DOWN", command = dwn)
b4.grid(row = 0, column = 3)

window.mainloop()