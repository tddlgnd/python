from tkinter import *

window = Tk()

def inval():
    z1 = float(y.get())
    z2 = z1 * 2.54
    x3['text'] = str(z2) + "cm"

x1 = Label(window, text = "인치 입력")
x1.grid(row = 0, column = 0)
x2 = Label(window, text = "변환 결과")
x2.grid(row = 1, column = 0)
x3 = Label(window, text = "센티미터")
x3.grid(row = 1, column = 1)
y = Entry(window)
y.grid(row = 0, column = 1)

button = Button(window, text = "변환", command = inval).grid(row = 2, column = 1)

window.mainloop()