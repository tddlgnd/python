import time
from tkinter import *

window = Tk()

canvas = Canvas(window, width = 300, height = 300)
canvas.pack()
c = canvas.create_text(5, 125, text="asd")
dx = 5
while True:
    canvas.move(c, dx, 0)
    x1, y1 = canvas.coords(c)
    if x1 < 0 or x1 > 300:
        dx = -dx
    window.update()
    time.sleep(0.05)
    
window.mainloop()