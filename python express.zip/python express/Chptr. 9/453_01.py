from tkinter import *

window = Tk()

def clk():
    x1['text'] = 'clicked'
    
x1 = Label(window, text="Hello")
x1.pack(side=LEFT)
button = Button(window, text = "Click", command = clk)
button.pack(side=RIGHT)

window.mainloop()