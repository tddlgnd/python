from tkinter import *

window = Tk()

x1 = Label(window, text = "이름")
x1.grid(row = 0, column = 0)
x2 = Label(window, text = "직업")
x2.grid(row = 1, column = 0)
x3 = Label(window, text = "국적")
x3.grid(row = 2, column = 0)

y1 = Entry(window).grid(row = 0, column = 1)
y2 = Entry(window).grid(row = 1, column = 1)
y3 = Entry(window).grid(row = 2, column = 1)

f = Frame(window)
z1 = Button(f, text = "Show").pack(side=LEFT)
z2 = Button(f, text = "Quit").pack(side=LEFT)
f.grid(row = 3, column = 0)

window.mainloop()