import random
a = open("numbers.txt", "w")
for i in range(10):
    x = random.randint(1, 99)
    a.write(f"{str(x)}\n")
a.close()