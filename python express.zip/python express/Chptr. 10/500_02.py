x = open("input.txt", "r")
cnt = 0
tmp = ' '

for y in x:
    y = y.rstrip()
    lst = y.split()
    for word in lst:
        word = word.strip("(),")
        a = len(word)
        if a > cnt:
            tmp = word
            cnt = a

print(tmp)
        
x.close()