a = open("input.txt", "r")
for i in range(3):
    x = a.readline().rstrip()
    print(x)