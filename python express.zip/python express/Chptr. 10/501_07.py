a = input("입력 파일 이름: ")
try:
    f = open(a, "w")
    f.write("test")
except IOError:
    print("ERROR")
finally:
    f.close()