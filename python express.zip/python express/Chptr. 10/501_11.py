a1 = open("input2.txt", "w")
a = open("input.txt", "r")
line = a.readlines()
cnt = 1
for i in line:
    a1.write(f"{cnt}: {i}")
    cnt+=1

a.close()
a1.close()