x = input("파일 이름을 입력: ")
y = open(x, "r")
dic = {}
space=0
tab=0
for line in y:
    for char in line.strip():  
       if char == " ":
           space+=1
       elif char == "    ":
           tab+=1
print(f"스페이스 수: {space} 탭 수: {tab}")
y.close()