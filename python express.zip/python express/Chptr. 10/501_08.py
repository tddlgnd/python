score = open("scores.txt", "r")
s1 = open("scores.txt", "a")
line = score.readline().rstrip()
val = 0
cnt = 0
while line != "":
    val += float(line)
    line = score.readline().rstrip()
    cnt+=1
result = val/cnt
x = str(round(result, 1))
s1.write(f"\n평균: {x}")
score.close()
s1.close()