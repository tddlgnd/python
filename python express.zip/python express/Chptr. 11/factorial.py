def fact(n):
    x = 1
    cnt = 1
    for i in range(n):
        x*=cnt
        cnt+=1
    return x