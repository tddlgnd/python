a = input("입력: ")
print(eval(a))