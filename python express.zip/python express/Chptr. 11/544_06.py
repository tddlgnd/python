import factorial as f

print(f.fact(4))