a = list(i for i in range(1, 11))
print(list(filter(lambda x : x%2 == 0, a)))
print(list(filter(lambda x : x%2 == 1, a)))